### Arguments

#### `argument_name`

* Is required: yes
* Is array: no
* Default: `NULL`

### Options

#### `--option_name|-o`

* Accept value: no
* Is value required: no
* Is multiple: no
* Default: `false`
