<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

class FinalMethod
{
    /**
     * @final
     */
    public function finalMethod()
    {
    }

    /**
     * @final
     */
    public function finalMethod2()
    {
    }

    public function anotherMethod()
    {
    }
}
