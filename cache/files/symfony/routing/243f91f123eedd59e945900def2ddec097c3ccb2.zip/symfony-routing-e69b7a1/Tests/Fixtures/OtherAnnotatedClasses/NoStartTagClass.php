class NoStartTagClass
{
}
